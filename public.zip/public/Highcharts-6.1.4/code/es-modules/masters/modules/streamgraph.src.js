/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 * Streamgraph module
 *
 * (c) 2010-2017 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/streamgraph.src.js';
